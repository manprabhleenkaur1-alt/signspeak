# Keep MediaPipe and ML Kit classes used via reflection / JNI
-keep class com.google.mediapipe.** { *; }
-dontwarn com.google.mediapipe.**
-dontwarn com.google.auto.value.**
