Place the MediaPipe hand landmark model in this folder with this exact name:

    hand_landmarker.task

Download it from:
https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/latest/hand_landmarker.task

Without it the Translate screen shows a "model missing" message instead of the camera.
