package com.signspeak.app.vm

import android.app.Application
import androidx.camera.core.ImageProxy
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import com.signspeak.app.data.AppLanguage
import com.signspeak.app.data.GestureClassifier
import com.signspeak.app.data.HandLandmarkerHelper
import com.signspeak.app.data.Languages
import com.signspeak.app.data.SignLesson
import com.signspeak.app.data.SignRepository
import com.signspeak.app.data.TranslationManager
import com.signspeak.app.data.TtsManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class TranslateUiState(
    val words: List<String> = emptyList(),
    val translated: String = "",
    val language: AppLanguage = Languages.default,
    val current: SignLesson? = null,
    val handVisible: Boolean = false,
    /** 0..1 progress of holding the current sign long enough to be accepted. */
    val progress: Float = 0f,
    val frontCamera: Boolean = true,
    val modelMissing: Boolean = false,
    val message: String? = null
)

class TranslateViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("signspeak", android.content.Context.MODE_PRIVATE)
    private val tts = TtsManager(app)
    private val translator = TranslationManager()
    private val repo = SignRepository()
    private var helper: HandLandmarkerHelper? = null

    private val _state = MutableStateFlow(
        TranslateUiState(language = Languages.byCode(prefs.getString(KEY_LANG, "en")))
    )
    val state: StateFlow<TranslateUiState> = _state.asStateFlow()

    // Detection stability: a sign must be held for HOLD_FRAMES frames to be accepted,
    // and the hand must change sign (or drop out) before the same word is added again.
    private var candidateId: String? = null
    private var streak = 0
    private var lastAcceptedId: String? = null

    init {
        helper = try {
            HandLandmarkerHelper(app, ::onLandmarks)
        } catch (e: Exception) {
            _state.update { it.copy(modelMissing = true) }
            null
        }
    }

    /** Called from the camera analyzer thread. */
    fun analyze(image: ImageProxy) {
        val h = helper
        if (h == null) {
            image.close()
        } else {
            h.detect(image, mirror = _state.value.frontCamera)
        }
    }

    private fun onLandmarks(landmarks: List<NormalizedLandmark>?) {
        if (landmarks == null) {
            resetDetection()
            _state.update { it.copy(handVisible = false, current = null, progress = 0f) }
            return
        }

        val lesson = GestureClassifier.classify(landmarks)
        if (lesson == null) {
            resetDetection()
            _state.update { it.copy(handVisible = true, current = null, progress = 0f) }
            return
        }

        if (lesson.id == candidateId) streak++ else {
            candidateId = lesson.id
            streak = 1
        }

        val progress = (streak.toFloat() / HOLD_FRAMES).coerceAtMost(1f)
        _state.update { it.copy(handVisible = true, current = lesson, progress = progress) }

        if (streak >= HOLD_FRAMES && lesson.id != lastAcceptedId) {
            lastAcceptedId = lesson.id
            addWord(lesson.word)
        }
    }

    private fun resetDetection() {
        candidateId = null
        streak = 0
        lastAcceptedId = null
    }

    private fun addWord(word: String) {
        _state.update { it.copy(words = it.words + word) }
        retranslate()
    }

    private fun retranslate() {
        val snapshot = _state.value
        viewModelScope.launch {
            translator.translate(snapshot.words, snapshot.language)
                .onSuccess { text -> _state.update { it.copy(translated = text) } }
                .onFailure {
                    _state.update {
                        it.copy(
                            translated = it.words.joinToString(" "),
                            message = "Couldn't translate. The first use of each language needs internet to download its model."
                        )
                    }
                }
        }
    }

    fun setLanguage(language: AppLanguage) {
        prefs.edit().putString(KEY_LANG, language.code).apply()
        _state.update { it.copy(language = language) }
        retranslate()
    }

    fun speak() {
        val s = _state.value
        val text = s.translated.ifBlank { s.words.joinToString(" ") }
        if (text.isBlank()) {
            _state.update { it.copy(message = "Sign something first, then tap Speak.") }
            return
        }
        if (!tts.speak(text, s.language.ttsTag)) {
            _state.update {
                it.copy(message = "No ${s.language.label} voice found. Install it in your phone's text-to-speech settings.")
            }
        }
    }

    fun removeLastWord() {
        _state.update { it.copy(words = it.words.dropLast(1)) }
        lastAcceptedId = null
        retranslate()
    }

    fun clear() {
        tts.stop()
        resetDetection()
        _state.update { it.copy(words = emptyList(), translated = "") }
    }

    fun save() {
        val s = _state.value
        if (s.words.isEmpty()) {
            _state.update { it.copy(message = "Nothing to save yet.") }
            return
        }
        viewModelScope.launch {
            repo.saveHistory(s.words.joinToString(" "), s.translated, s.language.label)
                .onSuccess { _state.update { it.copy(message = "Saved to history.") } }
                .onFailure { error ->
                    _state.update { it.copy(message = "Couldn't save: ${error.localizedMessage}") }
                }
        }
    }

    fun flipCamera() {
        resetDetection()
        _state.update { it.copy(frontCamera = !it.frontCamera, handVisible = false, current = null, progress = 0f) }
    }

    fun clearMessage() {
        _state.update { it.copy(message = null) }
    }

    override fun onCleared() {
        helper?.close()
        translator.close()
        tts.shutdown()
    }

    private companion object {
        const val HOLD_FRAMES = 12
        const val KEY_LANG = "language"
    }
}
