package com.signspeak.app.data

import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import kotlin.math.hypot

/**
 * One entry in the starter vocabulary. [pattern] is the finger state the camera
 * recognizer looks for, written as 5 digits in the order thumb, index, middle, ring, pinky
 * (1 = finger extended, 0 = curled).
 */
data class SignLesson(
    val id: String,
    val word: String,
    val punjabi: String,
    val emoji: String,
    val pattern: String,
    val handShape: String,
    val steps: List<String>,
    val tip: String
)

object SignLibrary {

    val lessons: List<SignLesson> = listOf(
        SignLesson(
            id = "hello", word = "Hello", punjabi = "ਸਤ ਸ੍ਰੀ ਅਕਾਲ", emoji = "🖐️", pattern = "11111",
            handShape = "Open palm, all five fingers spread",
            steps = listOf(
                "Raise your hand next to your face, palm facing the camera.",
                "Spread all five fingers, including the thumb.",
                "Hold still for a moment."
            ),
            tip = "Keep your hand about an arm's length from the camera so all fingers are visible."
        ),
        SignLesson(
            id = "yes", word = "Yes", punjabi = "ਹਾਂ", emoji = "✊", pattern = "00000",
            handShape = "Closed fist",
            steps = listOf(
                "Curl all four fingers into your palm.",
                "Wrap your thumb across the front of your fingers.",
                "Hold the fist steady, facing the camera."
            ),
            tip = "In everyday signing the fist nods up and down like a head nodding yes."
        ),
        SignLesson(
            id = "me", word = "Me", punjabi = "ਮੈਂ", emoji = "☝️", pattern = "01000",
            handShape = "Only the index finger pointing up",
            steps = listOf(
                "Make a loose fist.",
                "Extend only your index finger.",
                "Keep the thumb tucked in."
            ),
            tip = "When signing in conversation you point this finger at your own chest."
        ),
        SignLesson(
            id = "peace", word = "Peace", punjabi = "ਸ਼ਾਂਤੀ", emoji = "✌️", pattern = "01100",
            handShape = "Index and middle finger up in a V",
            steps = listOf(
                "Extend your index and middle fingers.",
                "Spread them apart slightly to form a V.",
                "Fold your ring finger, pinky and thumb down."
            ),
            tip = "Make sure the thumb is folded in, otherwise it can look like another shape."
        ),
        SignLesson(
            id = "iloveyou", word = "I love you", punjabi = "ਮੈਨੂੰ ਤੁਹਾਡੇ ਨਾਲ ਪਿਆਰ ਹੈ", emoji = "🤟", pattern = "11001",
            handShape = "Thumb, index finger and pinky extended",
            steps = listOf(
                "Extend your thumb, index finger and pinky.",
                "Fold your middle and ring fingers down.",
                "Hold the hand up, palm facing the camera."
            ),
            tip = "The shape combines the letters I, L and Y, which is why it means 'I love you'."
        ),
        SignLesson(
            id = "good", word = "Good", punjabi = "ਚੰਗਾ", emoji = "👍", pattern = "10000",
            handShape = "Thumb up, other fingers curled",
            steps = listOf(
                "Make a fist.",
                "Extend only your thumb, pointing upward.",
                "Keep the fist tight."
            ),
            tip = "Keep the thumb clearly away from the fist so the camera sees it as extended."
        ),
        SignLesson(
            id = "cool", word = "Cool", punjabi = "ਵਧੀਆ", emoji = "🤘", pattern = "01001",
            handShape = "Index finger and pinky extended",
            steps = listOf(
                "Extend your index finger and pinky.",
                "Fold your middle and ring fingers down.",
                "Tuck your thumb over the folded fingers."
            ),
            tip = "If it is read as 'I love you', tuck your thumb in more tightly."
        ),
        SignLesson(
            id = "water", word = "Water", punjabi = "ਪਾਣੀ", emoji = "🚰", pattern = "01110",
            handShape = "Three fingers up (the letter W)",
            steps = listOf(
                "Extend your index, middle and ring fingers.",
                "Fold your pinky down and hold it with your thumb.",
                "Hold the W shape facing the camera."
            ),
            tip = "In use, the W is tapped near the chin."
        ),
        SignLesson(
            id = "stop", word = "Stop", punjabi = "ਰੁਕੋ", emoji = "✋", pattern = "01111",
            handShape = "Flat hand, four fingers up, thumb tucked",
            steps = listOf(
                "Raise a flat hand with four fingers together.",
                "Fold your thumb across your palm.",
                "Face your palm toward the camera."
            ),
            tip = "The only difference from 'Hello' is the tucked thumb."
        ),
        SignLesson(
            id = "callme", word = "Call me", punjabi = "ਮੈਨੂੰ ਫ਼ੋਨ ਕਰੋ", emoji = "🤙", pattern = "10001",
            handShape = "Thumb and pinky extended (the letter Y)",
            steps = listOf(
                "Extend your thumb and your pinky.",
                "Fold your index, middle and ring fingers down.",
                "Hold the hand near your ear like a phone."
            ),
            tip = "Open the thumb and pinky wide so they are clearly separated."
        )
    )

    private val byPattern = lessons.associateBy { it.pattern }

    fun byId(id: String?): SignLesson? = lessons.firstOrNull { it.id == id }

    fun byPattern(pattern: String): SignLesson? = byPattern[pattern]

    /** Offline Punjabi translation for the built-in vocabulary (ML Kit has no Punjabi model). */
    fun punjabiFor(word: String): String =
        lessons.firstOrNull { it.word.equals(word, ignoreCase = true) }?.punjabi ?: word
}

/** Turns 21 MediaPipe hand landmarks into a finger pattern, then into a lesson. */
object GestureClassifier {

    fun fingerPattern(lm: List<NormalizedLandmark>): String {
        if (lm.size < 21) return ""

        fun dist(a: Int, b: Int): Float =
            hypot(lm[a].x() - lm[b].x(), lm[a].y() - lm[b].y())

        val palm = dist(0, 9).coerceAtLeast(0.0001f)

        // Four fingers: extended when the tip is clearly farther from the wrist than the middle joint.
        fun extended(tip: Int, pip: Int) = dist(0, tip) > dist(0, pip) * 1.25f

        // Thumb: extended when the tip is far from the base of the index finger.
        val thumb = dist(4, 5) > palm * 0.75f

        val index = extended(8, 6)
        val middle = extended(12, 10)
        val ring = extended(16, 14)
        val pinky = extended(20, 18)

        return listOf(thumb, index, middle, ring, pinky).joinToString("") { if (it) "1" else "0" }
    }

    fun classify(lm: List<NormalizedLandmark>): SignLesson? =
        SignLibrary.byPattern(fingerPattern(lm))
}
