package com.signspeak.app.ui

import androidx.activity.ComponentActivity
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.signspeak.app.vm.AuthViewModel
import com.signspeak.app.vm.DataViewModel
import com.signspeak.app.vm.TranslateViewModel

private data class Tab(val route: String, val label: String, val icon: ImageVector)

private val tabs = listOf(
    Tab("translate", "Translate", Icons.Default.Translate),
    Tab("learn", "Learn", Icons.Default.School),
    Tab("history", "History", Icons.Default.History),
    Tab("profile", "Profile", Icons.Default.Person)
)

@Composable
fun SignSpeakApp() {
    val authVm: AuthViewModel = viewModel()
    val user by authVm.user.collectAsStateWithLifecycle()

    if (user == null) {
        AuthScreen(authVm)
    } else {
        MainScaffold(authVm)
    }
}

@Composable
private fun MainScaffold(authVm: AuthViewModel) {
    // Activity-scoped so the sentence being signed survives tab switches.
    val activity = LocalContext.current as ComponentActivity
    val translateVm: TranslateViewModel = viewModel(viewModelStoreOwner = activity)
    val dataVm: DataViewModel = viewModel(viewModelStoreOwner = activity)

    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val route = backStack?.destination?.route

    Scaffold(
        bottomBar = {
            NavigationBar {
                tabs.forEach { tab ->
                    val selected = route == tab.route ||
                        (tab.route == "learn" && route?.startsWith("lesson") == true)
                    NavigationBarItem(
                        selected = selected,
                        onClick = { nav.navigateToTab(tab.route) },
                        icon = { Icon(tab.icon, contentDescription = tab.label) },
                        label = { Text(tab.label) }
                    )
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = nav,
            startDestination = "translate",
            modifier = Modifier.padding(padding)
        ) {
            composable("translate") { TranslateScreen(translateVm) }
            composable("learn") {
                LearnScreen(dataVm, onOpen = { id -> nav.navigate("lesson/$id") })
            }
            composable("lesson/{id}") { entry ->
                LessonDetailScreen(
                    lessonId = entry.arguments?.getString("id"),
                    vm = dataVm,
                    onBack = { nav.popBackStack() },
                    onPractice = { nav.navigateToTab("translate") }
                )
            }
            composable("history") { HistoryScreen(dataVm) }
            composable("profile") { ProfileScreen(authVm, dataVm) }
        }
    }
}

private fun NavHostController.navigateToTab(route: String) {
    navigate(route) {
        popUpTo(graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}
