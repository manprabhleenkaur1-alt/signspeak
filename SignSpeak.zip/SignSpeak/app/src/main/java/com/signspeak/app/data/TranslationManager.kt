package com.signspeak.app.data

import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.tasks.await

/**
 * English -> target language.
 * - English returns the text unchanged.
 * - Languages with an ML Kit model are translated on-device (the model downloads once, needs internet).
 * - Punjabi has no ML Kit model, so the built-in vocabulary is translated from an offline dictionary.
 */
class TranslationManager {

    private val translators = mutableMapOf<String, Translator>()

    suspend fun translate(words: List<String>, language: AppLanguage): Result<String> = runCatching {
        val english = words.joinToString(" ")
        when {
            english.isBlank() -> ""
            language.code == "en" -> english
            language.mlKitCode == null -> words.joinToString(" ") { SignLibrary.punjabiFor(it) }
            else -> {
                val translator = translators.getOrPut(language.mlKitCode) {
                    Translation.getClient(
                        TranslatorOptions.Builder()
                            .setSourceLanguage(TranslateLanguage.ENGLISH)
                            .setTargetLanguage(language.mlKitCode)
                            .build()
                    )
                }
                translator.downloadModelIfNeeded(DownloadConditions.Builder().build()).await()
                translator.translate(english).await()
            }
        }
    }

    fun close() {
        translators.values.forEach { it.close() }
        translators.clear()
    }
}
