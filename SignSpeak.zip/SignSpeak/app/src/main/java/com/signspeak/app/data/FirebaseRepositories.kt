package com.signspeak.app.data

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.tasks.await
import java.util.Date

class AuthRepository {
    private val auth = FirebaseAuth.getInstance()

    val currentUser: FirebaseUser? get() = auth.currentUser

    val user: Flow<FirebaseUser?> = callbackFlow {
        val listener = FirebaseAuth.AuthStateListener { trySend(it.currentUser) }
        auth.addAuthStateListener(listener)
        awaitClose { auth.removeAuthStateListener(listener) }
    }

    suspend fun signIn(email: String, password: String): Result<Unit> = runCatching {
        auth.signInWithEmailAndPassword(email.trim(), password).await()
        Unit
    }

    suspend fun signUp(email: String, password: String): Result<Unit> = runCatching {
        auth.createUserWithEmailAndPassword(email.trim(), password).await()
        Unit
    }

    /** Needs "Anonymous" sign-in enabled in the Firebase console. */
    suspend fun continueAsGuest(): Result<Unit> = runCatching {
        auth.signInAnonymously().await()
        Unit
    }

    fun signOut() = auth.signOut()
}

data class HistoryItem(
    @DocumentId val id: String = "",
    val words: String = "",
    val translated: String = "",
    val language: String = "",
    val createdAt: Date? = null
)

/**
 * Firestore layout (all under the signed-in user):
 *   users/{uid}/history/{autoId}   -> words, translated, language, createdAt
 *   users/{uid}/learned/{lessonId} -> learnedAt
 */
class SignRepository {
    private val auth = FirebaseAuth.getInstance()
    private val db = FirebaseFirestore.getInstance()

    private fun userDoc(uid: String) = db.collection("users").document(uid)

    private fun uidFlow(): Flow<String?> = callbackFlow {
        val listener = FirebaseAuth.AuthStateListener { trySend(it.currentUser?.uid) }
        auth.addAuthStateListener(listener)
        awaitClose { auth.removeAuthStateListener(listener) }
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    fun history(): Flow<List<HistoryItem>> = uidFlow().flatMapLatest { uid ->
        if (uid == null) flowOf(emptyList<HistoryItem>()) else callbackFlow<List<HistoryItem>> {
            val registration = userDoc(uid).collection("history")
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .addSnapshotListener { snapshot, _ ->
                    if (snapshot != null) trySend(snapshot.toObjects(HistoryItem::class.java))
                }
            awaitClose { registration.remove() }
        }
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    fun learned(): Flow<Set<String>> = uidFlow().flatMapLatest { uid ->
        if (uid == null) flowOf(emptySet<String>()) else callbackFlow<Set<String>> {
            val registration = userDoc(uid).collection("learned")
                .addSnapshotListener { snapshot, _ ->
                    if (snapshot != null) trySend(snapshot.documents.map { it.id }.toSet())
                }
            awaitClose { registration.remove() }
        }
    }

    suspend fun saveHistory(words: String, translated: String, language: String): Result<Unit> = runCatching {
        val uid = auth.currentUser?.uid ?: error("Not signed in")
        userDoc(uid).collection("history").add(
            hashMapOf(
                "words" to words,
                "translated" to translated,
                "language" to language,
                "createdAt" to FieldValue.serverTimestamp()
            )
        ).await()
        Unit
    }

    suspend fun deleteHistory(id: String): Result<Unit> = runCatching {
        val uid = auth.currentUser?.uid ?: error("Not signed in")
        userDoc(uid).collection("history").document(id).delete().await()
        Unit
    }

    suspend fun setLearned(lessonId: String, learned: Boolean): Result<Unit> = runCatching {
        val uid = auth.currentUser?.uid ?: error("Not signed in")
        val doc = userDoc(uid).collection("learned").document(lessonId)
        if (learned) doc.set(mapOf("learnedAt" to FieldValue.serverTimestamp())).await()
        else doc.delete().await()
        Unit
    }
}
