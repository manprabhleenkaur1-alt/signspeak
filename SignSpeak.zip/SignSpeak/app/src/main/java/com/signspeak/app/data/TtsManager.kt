package com.signspeak.app.data

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

/** Thin wrapper around Android's TextToSpeech that can switch language per call. */
class TtsManager(context: Context) : TextToSpeech.OnInitListener {

    private var ready = false
    private val tts = TextToSpeech(context.applicationContext, this)

    override fun onInit(status: Int) {
        ready = status == TextToSpeech.SUCCESS
    }

    /** Returns false when the engine isn't ready or has no voice for [languageTag]. */
    fun speak(text: String, languageTag: String): Boolean {
        if (!ready || text.isBlank()) return false
        val result = tts.setLanguage(Locale.forLanguageTag(languageTag))
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            return false
        }
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "signspeak")
        return true
    }

    fun stop() {
        tts.stop()
    }

    fun shutdown() {
        tts.stop()
        tts.shutdown()
    }
}
