package com.signspeak.app.vm

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseAuthException
import com.google.firebase.auth.FirebaseUser
import com.signspeak.app.data.AuthRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AuthViewModel : ViewModel() {
    private val repo = AuthRepository()

    val user: StateFlow<FirebaseUser?> =
        repo.user.stateIn(viewModelScope, SharingStarted.Eagerly, repo.currentUser)

    private val _busy = MutableStateFlow(false)
    val busy = _busy.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error = _error.asStateFlow()

    fun signIn(email: String, password: String) = run(email, password) { e, p -> repo.signIn(e, p) }

    fun signUp(email: String, password: String) = run(email, password) { e, p -> repo.signUp(e, p) }

    fun guest() {
        viewModelScope.launch {
            _busy.value = true
            _error.value = null
            repo.continueAsGuest().onFailure { _error.value = friendly(it) }
            _busy.value = false
        }
    }

    fun signOut() = repo.signOut()

    fun clearError() {
        _error.value = null
    }

    private fun run(email: String, password: String, block: suspend (String, String) -> Result<Unit>) {
        if (email.isBlank() || password.length < 6) {
            _error.value = "Enter an email and a password of at least 6 characters."
            return
        }
        viewModelScope.launch {
            _busy.value = true
            _error.value = null
            block(email, password).onFailure { _error.value = friendly(it) }
            _busy.value = false
        }
    }

    private fun friendly(t: Throwable): String {
        val code = (t as? FirebaseAuthException)?.errorCode
        return when (code) {
            "ERROR_INVALID_EMAIL" -> "That email address doesn't look right."
            "ERROR_WRONG_PASSWORD", "ERROR_INVALID_CREDENTIAL" -> "Incorrect email or password."
            "ERROR_USER_NOT_FOUND" -> "No account found for that email."
            "ERROR_EMAIL_ALREADY_IN_USE" -> "An account with that email already exists."
            "ERROR_WEAK_PASSWORD" -> "Choose a stronger password."
            "ERROR_OPERATION_NOT_ALLOWED" -> "This sign-in method is not enabled in the Firebase console."
            else -> t.localizedMessage ?: "Something went wrong. Check your connection and try again."
        }
    }
}
