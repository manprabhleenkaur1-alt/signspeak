package com.signspeak.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = Color(0xFF5B4BDB),
    secondary = Color(0xFF00897B),
    tertiary = Color(0xFFFF7043)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFB8B0FF),
    secondary = Color(0xFF4DB6AC),
    tertiary = Color(0xFFFFAB91)
)

@Composable
fun SignSpeakTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        content = content
    )
}
