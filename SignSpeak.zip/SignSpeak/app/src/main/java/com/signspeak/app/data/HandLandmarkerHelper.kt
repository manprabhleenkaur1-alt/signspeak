package com.signspeak.app.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.SystemClock
import androidx.camera.core.ImageProxy
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker

/**
 * Wraps MediaPipe's HandLandmarker in live-stream mode.
 * Throws if hand_landmarker.task is missing from the assets folder.
 */
class HandLandmarkerHelper(
    context: Context,
    private val onResult: (List<NormalizedLandmark>?) -> Unit
) {
    private val landmarker: HandLandmarker

    init {
        val base = BaseOptions.builder()
            .setModelAssetPath(MODEL_FILE)
            .build()

        val options = HandLandmarker.HandLandmarkerOptions.builder()
            .setBaseOptions(base)
            .setNumHands(1)
            .setMinHandDetectionConfidence(0.5f)
            .setMinHandPresenceConfidence(0.5f)
            .setMinTrackingConfidence(0.5f)
            .setRunningMode(RunningMode.LIVE_STREAM)
            .setResultListener { result, _ ->
                onResult(result.landmarks().firstOrNull())
            }
            .setErrorListener { onResult(null) }
            .build()

        landmarker = HandLandmarker.createFromOptions(context.applicationContext, options)
    }

    /** Takes ownership of [image] and closes it. */
    fun detect(image: ImageProxy, mirror: Boolean) {
        val rotation = image.imageInfo.rotationDegrees
        val width = image.width
        val height = image.height

        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        image.use { bitmap.copyPixelsFromBuffer(it.planes[0].buffer) }

        val matrix = Matrix().apply {
            postRotate(rotation.toFloat())
            if (mirror) postScale(-1f, 1f)
        }
        val upright = Bitmap.createBitmap(bitmap, 0, 0, width, height, matrix, true)

        landmarker.detectAsync(BitmapImageBuilder(upright).build(), SystemClock.uptimeMillis())
    }

    fun close() {
        landmarker.close()
    }

    companion object {
        const val MODEL_FILE = "hand_landmarker.task"
    }
}
