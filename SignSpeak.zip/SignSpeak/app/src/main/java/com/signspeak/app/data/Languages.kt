package com.signspeak.app.data

import com.google.mlkit.nl.translate.TranslateLanguage

data class AppLanguage(
    val code: String,
    val label: String,
    /** BCP-47 tag used for text-to-speech. */
    val ttsTag: String,
    /** ML Kit language code, or null when ML Kit has no model (Punjabi). */
    val mlKitCode: String?
)

object Languages {
    val all: List<AppLanguage> = listOf(
        AppLanguage("en", "English", "en-US", TranslateLanguage.ENGLISH),
        AppLanguage("hi", "Hindi (हिन्दी)", "hi-IN", TranslateLanguage.HINDI),
        AppLanguage("pa", "Punjabi (ਪੰਜਾਬੀ)", "pa-IN", null),
        AppLanguage("ja", "Japanese (日本語)", "ja-JP", TranslateLanguage.JAPANESE),
        AppLanguage("zh", "Chinese (中文)", "zh-CN", TranslateLanguage.CHINESE),
        AppLanguage("es", "Spanish (Español)", "es-ES", TranslateLanguage.SPANISH),
        AppLanguage("fr", "French (Français)", "fr-FR", TranslateLanguage.FRENCH),
        AppLanguage("de", "German (Deutsch)", "de-DE", TranslateLanguage.GERMAN),
        AppLanguage("ar", "Arabic (العربية)", "ar-SA", TranslateLanguage.ARABIC),
        AppLanguage("bn", "Bengali (বাংলা)", "bn-IN", TranslateLanguage.BENGALI),
        AppLanguage("gu", "Gujarati (ગુજરાતી)", "gu-IN", TranslateLanguage.GUJARATI),
        AppLanguage("mr", "Marathi (मराठी)", "mr-IN", TranslateLanguage.MARATHI),
        AppLanguage("ta", "Tamil (தமிழ்)", "ta-IN", TranslateLanguage.TAMIL),
        AppLanguage("te", "Telugu (తెలుగు)", "te-IN", TranslateLanguage.TELUGU),
        AppLanguage("ur", "Urdu (اردو)", "ur-PK", TranslateLanguage.URDU),
        AppLanguage("ko", "Korean (한국어)", "ko-KR", TranslateLanguage.KOREAN)
    )

    val default: AppLanguage = all.first()

    fun byCode(code: String?): AppLanguage = all.firstOrNull { it.code == code } ?: default
}
