package com.signspeak.app.vm

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.signspeak.app.data.HistoryItem
import com.signspeak.app.data.SignRepository
import com.signspeak.app.data.TtsManager
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class DataViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = SignRepository()
    private val tts = TtsManager(app)

    val history: StateFlow<List<HistoryItem>> =
        repo.history().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val learned: StateFlow<Set<String>> =
        repo.learned().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptySet())

    fun deleteHistory(id: String) {
        viewModelScope.launch { repo.deleteHistory(id) }
    }

    fun setLearned(lessonId: String, learned: Boolean) {
        viewModelScope.launch { repo.setLearned(lessonId, learned) }
    }

    /** Returns false when no voice is available for [languageTag]. */
    fun speak(text: String, languageTag: String): Boolean = tts.speak(text, languageTag)

    override fun onCleared() {
        tts.shutdown()
    }
}
