package com.signspeak.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.signspeak.app.ui.SignSpeakApp
import com.signspeak.app.ui.theme.SignSpeakTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SignSpeakTheme {
                SignSpeakApp()
            }
        }
    }
}
