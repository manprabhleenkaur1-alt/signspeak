# SignSpeak

Android app (Kotlin, Jetpack Compose, Firebase) that reads hand signs through the camera, turns them into text, translates the text, and speaks it aloud. Includes a Learn section for beginners.

## What's inside

| Feature | How it works |
|---|---|
| Sign to text | CameraX frames go to MediaPipe Hand Landmarker (on-device). The 21 hand landmarks are turned into a finger pattern and matched to the vocabulary. A sign must be held about half a second to be accepted. |
| Speak aloud | Android TextToSpeech, switching voice to the chosen language. |
| Translation | English by default. ML Kit on-device translation for Hindi, Japanese, Chinese, Spanish, French, German, Arabic, Bengali, Gujarati, Marathi, Tamil, Telugu, Urdu, Korean. Each language model downloads once (needs internet). |
| Punjabi | ML Kit has no Punjabi model, so Punjabi uses a built-in offline dictionary covering the app's vocabulary (`SignLibrary` in `Gestures.kt`). |
| Learn | 10 lessons with steps and tips, progress saved to Firestore, "Practice with camera" jumps to the Translate tab. |
| Firebase | Auth (email/password and guest), Firestore for saved phrases and learning progress. |

## Setup (about 10 minutes)

1. **Open the project** in Android Studio (Ladybug or newer) and let Gradle sync. If it complains about the Gradle wrapper, create a new "Empty Activity (Compose)" project named SignSpeak with package `com.signspeak.app` and copy the `app/src` folder and both `build.gradle.kts` files into it.
2. **Firebase project**
   - Go to the Firebase console, create a project, and add an Android app with package name `com.signspeak.app`.
   - Download `google-services.json` and put it in the `app/` folder (next to `app/build.gradle.kts`). The build will not work without it.
   - Authentication > Sign-in method: enable **Email/Password** and **Anonymous** (guest mode).
   - Firestore Database: create a database, then paste the contents of `firestore.rules` into the Rules tab and publish.
3. **Hand model**: download `hand_landmarker.task` from
   https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/latest/hand_landmarker.task
   and put it in `app/src/main/assets/`.
4. Run on a **real phone** (the emulator camera is poor for hand tracking). minSdk is 26.

## Using it

- Translate tab: show a hand to the camera and hold each sign steady. The word is added to the sentence, translated, and shown. Tap Speak to hear it. The bookmark button saves the phrase to History.
- To repeat the same word, relax your hand (or change sign) and make it again.
- Learn tab: pick a lesson, follow the steps, tap Practice with the camera.

## The starter vocabulary

Hello, Yes, Me, Peace, I love you, Good, Cool, Water, Stop, Call me.

These are static hand shapes the recognizer can match reliably. Real sign languages (ASL, ISL and others) also depend on movement, location and facial expression, so this is a learning and demo vocabulary, not full sign language interpretation. Treat the lesson descriptions as simplified.

## Extending it

- **Add a sign**: add a `SignLesson` in `Gestures.kt` with a unique 5-digit pattern (thumb, index, middle, ring, pinky; 1 = extended). It appears in Learn and is recognized automatically. Patterns must be unique.
- **Add a language**: add an `AppLanguage` in `Languages.kt` (ML Kit code and a TTS tag).
- **Fuller recognition**: for motion-based signs or whole alphabets, replace `GestureClassifier` with a trained model (for example a MediaPipe Gesture Recognizer custom model or a TFLite classifier on the landmarks).

## Project layout

```
app/src/main/java/com/signspeak/app/
  MainActivity.kt
  data/   Gestures.kt, Languages.kt, HandLandmarkerHelper.kt, TtsManager.kt,
          TranslationManager.kt, FirebaseRepositories.kt
  vm/     AuthViewModel.kt, TranslateViewModel.kt, DataViewModel.kt
  ui/     SignSpeakApp.kt (navigation), AuthScreen.kt, TranslateScreen.kt,
          LearnScreens.kt, HistoryScreen.kt, ProfileScreen.kt, theme/Theme.kt
```

## Troubleshooting

- "Hand model not found" on the Translate tab: step 3 above.
- Build error about `google-services.json`: step 2 above.
- Guest button fails: enable Anonymous sign-in in Firebase.
- No voice for a language: install that language's voice in Android Settings > Text-to-speech output.
- Signs flicker or are missed: use good light, keep the whole hand in frame, and keep the palm facing the camera.
